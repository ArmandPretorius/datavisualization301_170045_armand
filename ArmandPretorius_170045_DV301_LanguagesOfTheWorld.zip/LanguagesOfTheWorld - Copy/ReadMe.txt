WHEN COPYING PROJECT:

1. RUN "npm install"