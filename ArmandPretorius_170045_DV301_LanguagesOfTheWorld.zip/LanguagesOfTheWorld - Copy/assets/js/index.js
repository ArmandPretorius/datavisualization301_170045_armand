// //Searchbar animation
// $("#inpt_search").on('focus', function () {
// 	$(this).parent('label').addClass('active');
// });

// $("#inpt_search").on('blur', function () {
// 	if($(this).val().length == 0)
// 		$(this).parent('label').removeClass('active');
// });

//colours
var color =d3.scaleOrdinal()
.range(["#FFFFFF", "#EAEBEB", "#D5D6D8", "#BFC2C4", "#AAAEB0", "#95999C", "#808589", "#6B7175", "#555D61", "#40484E"]);

//url to csv file.
var csvUrl = "https://raw.githubusercontent.com/ArmandPretorius/languagesoftheworld/master/data.csv"

