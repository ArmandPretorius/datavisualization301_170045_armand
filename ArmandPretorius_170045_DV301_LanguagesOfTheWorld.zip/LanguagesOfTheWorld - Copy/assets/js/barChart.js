var margin2 = {top: 20, right: 20, bottom: 20, left: 20},
    width2 = 600 - margin2.left - margin2.right,
    height2 = 400 - margin2.top - margin2.bottom;


// set the ranges
var x = d3.scaleBand()
          .range([0, width2])
          .padding(0.1);
var y = d3.scaleLinear()
          .range([height2, 0]);

//tooltip
var tooltip2 = d3.select("#barChart")
              .append("div")
              .attr("class", "bar-tooltip")
              .style("position", "absolute")
              .style("color", "#dee2e6")
              .style("font-family", "Roboto")
              .style("font-size", "12px")
              .style("right", 0)
              .style("opacity", 0.9)
              .style("margin-right", "30px")
              .style("margin-top", "0px")
              .style("z-index", "10")
              .style("visibility", "hidden")
              .style("background", "none")
              .text("a simple tooltip");
          
// append the svg object to the body of the page
// append a 'group' element to 'svg'
// moves the 'group' element to the top left margin
var svg2 = d3.select("#barChart").append("svg")
    .attr("width", width2 + margin2.left + margin2.right)
    .attr("height", height2 + margin2.top + margin2.bottom)
    // .data(dataLanguage).enter()
    .append("g")
    .attr("transform", 
          "translate(" + margin2.left + "," + margin2.top + ")");
        

// get the data
d3.csv(csvUrl, function(error, data) {
  if (error) throw error;

  // format the data
  data.forEach(function(d) {
    d.countries = +d.countries;
  });

  // Scale the range of the data in the domains
  x.domain(data.map(function(d) { return d.language; }));
  y.domain([0, d3.max(data, function(d) { return d.countries; })]);

  // append the rectangles for the bar chart
  svg2.selectAll(".bar")
      .data(data)
    .enter().append("rect")
      .attr("class", "bar")
      .attr("x", function(d) { return x(d.language); })
      .attr("width", x.bandwidth())
      .style("fill", function(d) {
        return color(d.countries); 
      })
      .on("mouseover", function(d){
        tooltip2.transition()		
        .duration(200)		
        .style("opacity", .9);
            tooltip2.html("Language: <b>" + d.language + "</b><br/> Number of Countries: <b>" + d.countries + "</b>"); 
            return tooltip2.style("visibility", "visible");
          })
          .on("mousemove", function(){
                return tooltip2.style("top", d3.event.y).style("left",d3.event.x);
              })
              .on("mouseout", function(){
                tooltip2.transition()		
                .duration(500)		
                .style("opacity", 0);	
                  return tooltip2.style("visibility", "hidden");
              })
      .attr("height", height2 )
      .transition()
      .duration(600)
      .delay(function (d, i) {
        return i * 50;
      })
      .ease(d3.easeExp)
      .attr("y", function(d) { return y(d.countries); })
      .attr("height", function(d) { return height2 - y(d.countries); });



  // add the x Axis
  svg2.append("g")
      .attr("transform", "translate(0," + height2 + ")");


});


