//data call csv

// margin3
var margin3 = {top: 20, right: 20, bottom: 20, left: 20},
    width3 = 400 - margin3.right - margin3.left,
    height3 = 400 - margin3.top - margin3.bottom,
    radius = width3/2;


// arc generator
var arc = d3.arc()
.outerRadius(radius - 10)
.innerRadius(radius - 70);

var labelArc = d3.arc()
    .outerRadius(radius- 40)
    .innerRadius(radius - 40);

// pie generator
var pie = d3.pie()
    .sort(null)
    .value(function(d){
        return d.users;
    });


//tooltip
var div = d3.select("#pieChart").append("div")	
    .attr("class", "tooltip")				
    .style("opacity", 0);


//define svg

var svg3 = d3.select("#pieChart").append('svg')
    .attr("width", width3)
    .attr("align", "center")
    .attr("height", height)
    .append("g")
    .attr("transform", "translate(" + width3/2 + "," + height3/2 + ")");

//import data

d3.csv(csvUrl, function(error, data) {
    if (error) throw error;

    //parse the data
    data.forEach(function(d){
        d.users = +d.users; // + turns the number into integer
        d.language = d.language;
    });

    //append g elements - arc
    var g = svg3.selectAll(".arc")
        .data(pie(data))
        .enter()
        .append("g")
        .attr("class", "arc")
        .on("mouseover", function(d) {		
            div.transition()		
                .duration(200)		
                .style("opacity", .9);		
            div	.html("Language: <b>" + d.data.language + "</b><br/>"  + "Number of Users: <b>" + d.data.users + "</b>")	
            })					
        .on("mouseout", function(d) {		
            div.transition()		
                .duration(500)		
                .style("opacity", 0);	
        });

    //append the ppath of the arc
    g.append("path")
        .attr("d", arc)
        .style("fill", function(d) {
            return color(d.data.language); 
        })
        .transition()
        .ease(d3.easeExp)
        .duration(2000)
        .attrTween("d", pieTween);

});

function pieTween(b){
    b.innerRadius = 0;
    var i = d3.interpolate(
        {starAngle: 0, endAngle: 0}, b
    );
    return function(t) {
        return arc(i(t));
    };

}
