
var nodes = [
  {'type': 'newspaper', 'name': 'Zeit'}, 
  {'type': 'newspaper', 'name': 'BBC'}, 
  {'type': 'newspaper', 'name': 'The Guardian'}, 
  {'type': 'newspaper', 'name': 'Volkskrant'}, 
  {'type': 'newspaper', 'name': 'NYTimes'}, 
  {'type': 'plugin', 'name': 'Flashtalking'}, 
  {'type': 'plugin', 'name': 'Integral Ad Science'}, 
  {'type': 'plugin', 'name': 'xplosion'}, 
  {'type': 'plugin', 'name': 'Rocket Fuel'}, 
  {'type': 'plugin', 'name': 'BrightRoll'}, 
  {'type': 'plugin', 'name': 'New Relic'}, 
  {'type': 'plugin', 'name': 'Rubicon'}, 
  {'type': 'plugin', 'name': 'Quantcast'}, 
  {'type': 'plugin', 'name': 'VisualDNA'}, 
  ];

var links = [{'source': 0, 'target': 6}, {'source': 0, 'target': 7}, ];

var w= 500, h = 500;

var svg = d3.select('#worldChart').append('svg')
  .style("background", "#FFF")
  .attr('width', w)
  .attr('height', h);

//var colours = d3.scale.category10();

var force = d3.layout.force()
  .size([w, h])
  .charge(function(d){
    return (d.type == 'newspaper')? -880 : -80;
   })
  .linkDistance(0.6*w)
  .gravity(0.4);

force.nodes(nodes);
force.links(links);


var gen = d3.svg.diagonal();

var link = svg.selectAll("path")
            .data(force.links())
            .enter()
            .append("path")
            .attr("stroke", '#aec7e8')
            .attr("stroke-width", "2px")
            .attr("fill", "none")
            .style("opacity", 0.35);

var node = svg.selectAll('text')
            .data(force.nodes())
            .enter()
            .append('text')
            .text(function(d){ 
              return d.name; 
             })
            .style("text-anchor", "middle")
            .attr('font-size', function(d){
              return (d.type == 'newspaper')? 28 : 14;
             })
            .style("fill", function(d,i){ 
              return (d.type == 'newspaper')? '#1f77b4' : '#ff7f0e';
             })
            .style("opacity",function(d){
              return (d.type == 'newspaper')? 0.99 : 0.60;
             })
            .call(force.drag);


force.on('tick', function() {

  node.attr('x', function(d) { 
          return d.x; 
       })
      .attr('y', function(d) { 
          return d.y; 
       });

  link.attr("d", gen);
        
});


force.start();






















var w = 960, h = 400, margin = 20;

var all_tracks = [];

var svg = d3.select('#worldChart')
            .append('svg')
            .attr('width', w)
            .attr('height', h);



var nodes = null,
    labels = null;

d3.csv(csvUrl, function(error, data){
  var ranks = data.language;
//   ranks = ranks.sort(function(a,b){
//     var a = parseInt(a.rank, 10);
//     var b = parseInt(b.rank, 10);
//     return (a == b)? 0 : ( (a > b)? -1 : 1 );
//   })
  draw(ranks);
});

// Change scale according to number of ranks to be shown
var set_scales = function(ranks){
  
  var xDomain = d3.extent(ranks, function(d){ 
    return parseInt(d.rank, 10); 
  });
  
  var yDomain = d3.extent(ranks, function(d){ 
    return parseInt(d.users, 10); 
  });

  return {
    'xScale': d3.scaleLinear() 
                // .domain(xDomain)
                .range([margin, w-margin]), 

    'yScale': d3.scaleLinear()
                // .domain(yDomain)
                .range([h-margin, margin])
  }
}  

// Draws and set everything at first
var draw = function(ranks){

  // Define x and y scales,
  // base on number of ranks we have
  var scales = set_scales(ranks);
  var xScale = scales.xScale;
  var yScale = scales.yScale; 

  nodes = svg.selectAll('node')
           .data(ranks)
           .enter()
           .append('circle')
           .attr('class', 'node')
           .attr('cx', function(d,i){ 
              return xScale(d.rank);
            })
           .attr('cy', function(d,i){ 
              return yScale(d.users);
            })
           .attr('r', function(d,i){
              // ranks ranked higher get bigger dots 
              return 25*Math.pow(0.96,i);
            })
           .attr("fill", function(d,i){ 
              return color(d.language);
            })
           .on('mouseover', function(d,i){
              // Set label to track/atrist names upon hover
              d3.select('#top_label')
                .text(' ' + d.language + ': ' + d.rank );
            })
           .on('mouseout', function(d,i){
              // Set label back to number of ranks we have
              d3.select('#top_label')
                .text('')
            });

  all_tracks = ranks;

  // Set labels to number of ranks retrieved.
  d3.select('#top_label')
    .text('');

}

// Moves dots when slider is changed
var filter = function(n){

  // We only want top n ranks, 
  // The value of n is set by the slider.
  var ranks = all_tracks.slice(0, n);
  // Define x and y scales accordingly
  var scales = set_scales(ranks);
  var xScale = scales.xScale;
  var yScale = scales.yScale; 

  d3.select('#top_label').text('');

  nodes.transition()
       .duration(2000)
       .attr('cx', function(d,i){ 
          return xScale(d.rank);
        })
       .attr('cy', function(d,i){ 
          return yScale(d.users);
        })
       .style("opacity",function(d, i){
          return (i>n)? 0 : 1;
        });

}  
